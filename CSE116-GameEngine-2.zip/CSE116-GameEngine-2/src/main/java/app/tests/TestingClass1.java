package app.tests;

import app.gameengine.Level;
import app.gameengine.model.ai.Decision;
import app.gameengine.model.datastructures.BinaryTreeNode;
import app.gameengine.model.gameobjects.DynamicGameObject;

public class TestingClass1 extends Decision {
    private boolean decideDirectionTraverse;
    private BinaryTreeNode<Decision> node;
    private boolean doActionCall = false;
    public TestingClass1(String DecisionName,boolean decideDirectionTraverse) {
        super(DecisionName);
        this.decideDirectionTraverse = decideDirectionTraverse;
    }
    @Override
    public boolean decide(DynamicGameObject object, Level level, double dt){
        return decideDirectionTraverse;
    }
    @Override
    public void doAction(DynamicGameObject object, Level level, double dt){
//        if(node.getLeft() == null & node.getRight() == null){
            doActionCall = true;
    }
    public boolean isDoActionCall(){
        return doActionCall;
    }


    }
//}

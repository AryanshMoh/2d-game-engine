package app.gameengine.model.physics;

public interface Collidable {

    Hitbox getHitBox();

}

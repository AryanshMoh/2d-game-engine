package app.gameengine.model.ai;

import app.gameengine.model.datastructures.LinkedListNode;
import app.gameengine.model.physics.Vector2D;

import java.util.LinkedList;

public class Pathfinding {
    public static LinkedListNode<Vector2D> findPath(Vector2D object1, Vector2D object2) {
        Vector2D start = new Vector2D(Math.floor(object1.getX()), Math.floor(object1.getY()));
        Vector2D end = new Vector2D(Math.floor(object2.getX()), Math.floor(object2.getY()));
        return pathHelper(start, end);
    }
    private static LinkedListNode<Vector2D> pathHelper(Vector2D start, Vector2D end){
        if(start.equals(end)){
            return new LinkedListNode<>(start,null);
        }
        int changeX = (int) (end.getX() - start.getX());
        int changeY = (int) (end.getY() - start.getY());
        if (changeY != 0) {
            int move = 0;
            if (changeY < 0) {
                move = -1;
            } else {
                move = 1;
            }
            Vector2D nextMove = new Vector2D(start.getX(), start.getY() + move);
            return new LinkedListNode<>(start, pathHelper(nextMove, end));

        }
        if(changeX != 0) {
            int move = 0;
            if (changeX < 0) {
                move = -1;
            } else {
                move = 1;
            }
            Vector2D nextMove = new Vector2D(start.getX() + move, start.getY());
            return new LinkedListNode<>(start, pathHelper(nextMove,end));
        }
        return new LinkedListNode<>(start,null);
    }


}
